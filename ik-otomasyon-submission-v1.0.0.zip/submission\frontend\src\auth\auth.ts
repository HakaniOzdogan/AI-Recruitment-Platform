﻿import { loginRequest } from "../api/endpoints/auth";

const TOKEN_KEY = "ik_demo_access_token";

let unauthorizedHandler: (() => void) | null = null;

export function getToken(): string | null {
  return localStorage.getItem(TOKEN_KEY);
}

export function setToken(token: string): void {
  localStorage.setItem(TOKEN_KEY, token);
}

export function setUnauthorizedHandler(handler: (() => void) | null): void {
  unauthorizedHandler = handler;
}

export function triggerUnauthorized(): void {
  if (unauthorizedHandler) {
    unauthorizedHandler();
  }
}

export function logout(): void {
  localStorage.removeItem(TOKEN_KEY);
}

export async function login(email: string, password: string): Promise<void> {
  const result = await loginRequest({ email, password });
  setToken(result.accessToken);
}

export function isAuthenticated(): boolean {
  return Boolean(getToken());
}
