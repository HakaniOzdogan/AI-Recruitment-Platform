﻿export type AppRuntimeConfig = {
  API_BASE_URL?: string;
};

function fromRuntime(): string | undefined {
  if (typeof window === "undefined") {
    return undefined;
  }

  return window.__APP_CONFIG__?.API_BASE_URL?.trim();
}

const runtimeApiBaseUrl = fromRuntime();
const viteApiBaseUrl = import.meta.env.VITE_API_BASE_URL?.trim();

export const API_BASE_URL = runtimeApiBaseUrl || viteApiBaseUrl || "http://localhost:8080";
