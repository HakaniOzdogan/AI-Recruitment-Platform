﻿import { ArrowRight, Briefcase, MessageCircle, UserPlus } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { getCandidates } from "../api/endpoints/candidates";
import { getJobs } from "../api/endpoints/jobs";
import { EmptyState } from "../components/EmptyState";
import { ErrorState } from "../components/ErrorState";
import { LoadingSkeleton } from "../components/LoadingSkeleton";
import { PageHeader } from "../components/PageHeader";

function CtaCard({
  to,
  title,
  desc,
  icon,
  disabled
}: {
  to?: string;
  title: string;
  desc: string;
  icon: JSX.Element;
  disabled?: boolean;
}): JSX.Element {
  const content = (
    <div className={`card modern-card cta-card ${disabled ? "is-disabled" : ""}`} title={disabled ? "Önce Job ve Candidate ekle" : undefined}>
      <div className="row-actions">
        <div className="icon-chip">{icon}</div>
        <ArrowRight size={16} />
      </div>
      <h3>{title}</h3>
      <p className="muted">{desc}</p>
    </div>
  );

  if (!to || disabled) {
    return content;
  }

  return <Link to={to}>{content}</Link>;
}

export function DashboardPage(): JSX.Element {
  const [jobsCount, setJobsCount] = useState<number | null>(null);
  const [candidatesCount, setCandidatesCount] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);

  async function loadSummary() {
    setLoading(true);
    setLoadError(null);
    try {
      const [jobs, candidates] = await Promise.all([getJobs(), getCandidates()]);
      setJobsCount(jobs.length);
      setCandidatesCount(candidates.length);
    } catch {
      setLoadError("Özet verisi alınamadı.");
      setJobsCount(null);
      setCandidatesCount(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadSummary();
  }, []);

  const startInterviewDisabled = (jobsCount ?? 0) === 0 || (candidatesCount ?? 0) === 0;

  return (
    <section className="page-stack">
      <PageHeader title="Dashboard" subtitle="Hizli baslangic aksiyonlari" />

      {loading ? <LoadingSkeleton lines={4} /> : null}
      {loadError ? <ErrorState message={loadError} onRetry={() => void loadSummary()} /> : null}

      {!loading && !loadError ? (
        <>
          <div className="dashboard-grid">
            <CtaCard to="/jobs?create=1" title="Create Job" desc="Yeni ilan olusturup yayinlayin." icon={<Briefcase size={18} />} />
            <CtaCard to="/candidates?create=1" title="Add Candidate" desc="Aday ekleyin ve CV parse akisina gecin." icon={<UserPlus size={18} />} />
            <CtaCard
              to={startInterviewDisabled ? undefined : "/jobs"}
              title="Start Interview"
              desc={startInterviewDisabled ? "Önce Job ve Candidate ekle" : "Application uzerinden mulakat baslatin."}
              icon={<MessageCircle size={18} />}
              disabled={startInterviewDisabled}
            />
          </div>

          <div className="dashboard-grid dashboard-stats">
            <div className="card modern-card">
              <h3>Jobs</h3>
              <p className="dashboard-metric">{jobsCount ?? "-"}</p>
            </div>
            <div className="card modern-card">
              <h3>Candidates</h3>
              <p className="dashboard-metric">{candidatesCount ?? "-"}</p>
            </div>
            <div className="card modern-card">
              <h3>Akis Durumu</h3>
              <p className="muted">{startInterviewDisabled ? "Kurulum gerekli" : "Interview baslatmaya hazirsin"}</p>
            </div>
          </div>

          <div className="card modern-card">
            <h3>Quick Steps</h3>
            <ol className="quick-steps">
              <li>Job olustur + publish et.</li>
              <li>Candidate olustur + CV yukle.</li>
              <li>Job'a candidate ekle (application).</li>
              <li>Interview baslat + mesaj gonder.</li>
              <li>Auto score calistir.</li>
            </ol>
          </div>

          <div className="card modern-card">
            <h3>Recent Activity</h3>
            <EmptyState title="Henüz veri yok" message="Jobs veya Candidates sayfasindan ilk kaydi olusturarak baslayin." />
          </div>
        </>
      ) : null}
    </section>
  );
}
