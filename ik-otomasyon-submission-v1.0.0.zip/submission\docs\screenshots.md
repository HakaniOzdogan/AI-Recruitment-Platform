# Screenshot Evidence

## Required Files
- `screenshots/01-jobs.png`
- `screenshots/02-job-detail.png`
- `screenshots/03-interview.png`

## What Each Screenshot Proves
1. `01-jobs.png`
- Modern list page shell (sidebar + topbar)
- Jobs card/table layout
- Search and row actions visibility

2. `02-job-detail.png`
- Job header card (title + status)
- 3-panel grid (Weights / Matching / Applications)
- Panel-level state handling area

3. `03-interview.png`
- Split layout (chat left, score/debug right)
- Scorecard panel with criteria area
- AI debug panel and action buttons

## Capture Notes
- Current files are placeholders; replace with live app captures before final presentation.
- Keep same demo dataset to avoid inconsistent UI evidence.
- Do not include PII in screenshots.
