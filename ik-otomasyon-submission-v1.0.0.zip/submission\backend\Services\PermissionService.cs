using IkOtomasyon.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace IkOtomasyon.Api.Services;

public class PermissionService
{
    private readonly AppDbContext _db;

    public PermissionService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<bool> HasPermissionAsync(Guid userId, string permissionKey, CancellationToken ct = default)
    {
        return await _db.UserRoles
            .Where(ur => ur.UserId == userId)
            .SelectMany(ur => ur.Role!.RolePermissions)
            .AnyAsync(rp => rp.Permission!.Key == permissionKey, ct);
    }
}
