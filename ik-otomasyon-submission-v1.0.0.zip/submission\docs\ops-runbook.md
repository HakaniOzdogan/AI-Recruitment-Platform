﻿# Ops Runbook

## 1) Tek komut full stack (run-demo)
- Windows (PowerShell):
```powershell
powershell -ExecutionPolicy Bypass -File ops/run-demo.ps1
```
- Linux/Mac:
```bash
bash ops/run-demo.sh
```

Run-demo akisi:
1. `.env.prod` yoksa `.env.prod.example` kopyalanir.
2. `JWT_SECRET` yok/placeholder ise guclu deger uretilir.
3. `db -> migrate -> api -> web` sirasi ile ayağa kalkar.
4. Ready check (API + Web) yapar.
5. Smoke + Evidence adimlarini dener (birisi fail olsa da digeri yine calisir).

Beklenen son mesaj:
- `Open http://localhost:3000`
- `Next: follow docs/demo-seed-5min.md`

## 2) Tek komut teslim paketi
- Windows (PowerShell):
```powershell
powershell -ExecutionPolicy Bypass -File ops/build-submission.ps1
```
- Linux/Mac:
```bash
bash ops/build-submission.sh
```

Beklenen ciktilar:
- Zip: `ik-otomasyon-submission-v{VERSION}.zip`
- Manifest: `submission/MANIFEST.txt`

## 3) Evidence ciktilari
- Klasor: `evidence/YYYYMMDD-HHMM/`
- Beklenen dosyalar:
- `swagger.json` (API ayaktaysa)
- `migrations.txt`
- `vuln.txt`
- `tests/unit/unit.trx`
- `tests/integration/integration.trx`
- (fallback) `tests/tests-<timestamp>.trx`

## 4) Temizlik
```bash
docker compose -f docker-compose.prod.yml --env-file .env.prod down -v
```
