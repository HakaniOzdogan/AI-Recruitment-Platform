﻿import { AlertTriangle } from "lucide-react";

export function ErrorState({ message, onRetry, reference }: { message: string; onRetry?: () => void; reference?: string | null }): JSX.Element {
  return (
    <div className="error-state">
      <AlertTriangle size={18} />
      <p>{message}</p>
      {reference ? <p className="muted">Ref: {reference}</p> : null}
      {onRetry ? (
        <button type="button" className="button secondary" onClick={onRetry}>
          Retry
        </button>
      ) : null}
    </div>
  );
}
