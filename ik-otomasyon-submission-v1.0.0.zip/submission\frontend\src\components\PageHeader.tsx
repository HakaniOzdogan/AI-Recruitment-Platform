export function PageHeader({ title, subtitle, actions }: { title: string; subtitle?: string; actions?: JSX.Element }): JSX.Element {
  return (
    <div className="page-header">
      <div>
        <h2>{title}</h2>
        {subtitle ? <p className="muted">{subtitle}</p> : null}
      </div>
      {actions ? <div className="row-actions">{actions}</div> : null}
    </div>
  );
}
