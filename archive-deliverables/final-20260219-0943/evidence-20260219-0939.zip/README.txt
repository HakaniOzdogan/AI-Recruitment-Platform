﻿Evidence bundle generated at: 20260219-0939
API base: http://localhost:8080
Files:
- swagger.json
- migrations.txt
- vuln.txt
- ci-summary.txt
- tests/*.trx
