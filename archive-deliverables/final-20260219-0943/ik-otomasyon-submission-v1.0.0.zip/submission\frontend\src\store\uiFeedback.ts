﻿export type ToastItem = {
  id: string;
  type: "error" | "info";
  message: string;
};

type Listener = () => void;

let toasts: ToastItem[] = [];
let forbiddenMessage: string | null = null;
const listeners = new Set<Listener>();

function notify(): void {
  listeners.forEach((listener) => listener());
}

export function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function getSnapshot() {
  return { toasts, forbiddenMessage };
}

export function pushToast(type: ToastItem["type"], message: string): void {
  toasts = [...toasts, { id: crypto.randomUUID(), type, message }];
  notify();
}

export function removeToast(id: string): void {
  toasts = toasts.filter((item) => item.id !== id);
  notify();
}

export function setForbidden(message: string | null): void {
  forbiddenMessage = message;
  notify();
}

export function clearForbidden(): void {
  setForbidden(null);
}
