﻿import { FormEvent, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { login } from "../auth/auth";

export function LoginPage(): JSX.Element {
  const [email, setEmail] = useState("admin@local.test");
  const [password, setPassword] = useState("Admin123!");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setError(null);
    setLoading(true);

    try {
      await login(email.trim(), password);
      const returnUrl = new URLSearchParams(location.search).get("returnUrl");
      const from = (location.state as { from?: string } | null)?.from;
      navigate(returnUrl || from || "/jobs", { replace: true });
    } catch {
      setError("Giriş başarısız");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="login-wrap">
      <form className="card" onSubmit={handleSubmit}>
        <h1>Login</h1>

        <label>
          Email
          <input value={email} onChange={(event) => setEmail(event.target.value)} />
        </label>

        <label>
          Password
          <input type="password" value={password} onChange={(event) => setPassword(event.target.value)} />
        </label>

        {error ? <p className="inline-error">{error}</p> : null}

        <button type="submit" disabled={loading}>
          {loading ? "Bekleyin..." : "Login"}
        </button>
      </form>
    </div>
  );
}
