# Acceptance Sign-off

Date: 2026-02-19
Release: `1.0.0`

Status kullanimi:
- `PASS` = kabul edildi
- `FAIL` = bloklayici sorun var

## 1) Functional
| Requirement | Status (PASS/FAIL) | Evidence (docs/test/screenshot) | Notes |
|---|---|---|---|
| Jobs (create/list/publish/weights) | PASS | `docs/demo-10min-cheatsheet.md`, `docs/ui-happy-path.md`, `docs/screenshots.md` (`01-jobs.png`, `02-weights.png`) | UI akista dogrulandi |
| Candidates (create/list) | PASS | `docs/demo-seed-5min.md`, `docs/ui-smoke.md` | Empty-state CTA mevcut |
| CV upload/parse/profile | PASS | `sample-data/sample-candidate.pdf`, `sample-data/sample-candidate.docx`, `docs/ui-smoke.md` | Sample imza dogrulamasi gecti |
| Matching shortlist (reasons/gaps) | PASS | `docs/demo-script.md`, `docs/ui-smoke.md`, `docs/screenshots.md` (`03-matches.png`) | minScore + reasons/gaps gorunur |
| Applications + stage updates | PASS | `docs/ui-happy-path.md`, `docs/demo-script.md` | 409 duplicate davranisi net |
| Interview chat flow | PASS | `docs/ui-happy-path.md`, `docs/screenshots.md` (`08-interview-chat.png`) | load/send/refresh dogrulandi |
| Adaptive mode + fallback g�r�n�rl�k | PASS | `docs/demo-failure-cases.md`, `docs/screenshots.md` (`09-ai-debug.png`) | 409 + debug flags gorunur |
| Scoring auto + insufficient evidence | PASS | `evidence/20260219-0106/tests/tests-20260219-005000.trx`, `docs/ui-happy-path.md` | Insufficient evidence davranisi testte mevcut |
| Human override (validation dahil) | PASS | `evidence/20260219-0106/tests/tests-20260219-005000.trx`, `docs/ui-happy-path.md` | 400 validasyon davranisi korunuyor |
| AI evaluation latest + force | PASS | `docs/demo-script.md`, `docs/ui-smoke.md`, `docs/screenshots.md` (`06-ai-eval.png`) | consent/forbidden/error state mevcut |

## 2) Security / Ops
| Requirement | Status (PASS/FAIL) | Evidence (docs/test/script) | Notes |
|---|---|---|---|
| RBAC / permission checks (401/403) | PASS | Integration tests, `docs/evidence-pack.md` | 401/403 davranisi net |
| `/jobs/{id}/weights` authorization | PASS | Integration test: `JobsWeights_Get_RequiresPermission` | Yetkisiz erisim engelli |
| Secrets via env + JWT fail-fast | PASS | `README.md`, `docs/troubleshooting.md`, `ops/run-demo.*` | JWT_SECRET olmadan deploy bloklu |
| Vulnerability scan gate (High=0 hedefi) | PASS | `evidence/20260219-0106/vuln.txt`, CI workflow | High yok |
| Rate limiting + security headers | PASS | `docs/go-live.md`, `ops/security-check.sh` | Prod checklistte mevcut |
| Audit log + correlationId visibility | PASS | `docs/correlation-proof.md`, `docs/evidence-pack.md`, `docs/screenshots.md` (`10-correlation-toast.png`) | UI Ref + log eslestirme var |

## 3) Quality / Release
| Requirement | Status (PASS/FAIL) | Evidence | Notes |
|---|---|---|---|
| Unit + integration tests | PASS | `evidence/20260219-0106/tests/tests-20260219-005000.trx` | Testler gecti, TRX ayrimi iyilestirme backlog'ta |
| CI gates aktif | PASS | `.github/workflows/ci.yml` | build/test + drift + vuln |
| run-demo scripts ready | PASS | `ops/run-demo.ps1` run log (2026-02-19), `docker-compose.prod.yml`, `frontend/Dockerfile` | run-demo zinciri (db->migrate->api->web) calisiyor |
| smoke + evidence scripts ready | PASS | `ops/smoke-test.ps1`, `evidence/20260219-0106/swagger.warn.txt` | Smoke script NullReference vermeden PASS/WARN ozetliyor; evidence best-effort toplaniyor |
| Submission bundle �retimi | PASS | `ops/build-submission.sh`, `ops/build-submission.ps1`, `submission/MANIFEST.txt` | secrets/exclude kurallari var |
| Secrets/PII final scan | PASS | `docs/pre-freeze-report.md`, `ops/pre-freeze-check.ps1` | Warn'lar false-positive/script pattern kaynakli |

## 4) Signatures
- Product/Project Owner: ____________________  Date: __________
- Tech Lead: ________________________________  Date: __________
- QA/Reviewer: ______________________________  Date: __________



