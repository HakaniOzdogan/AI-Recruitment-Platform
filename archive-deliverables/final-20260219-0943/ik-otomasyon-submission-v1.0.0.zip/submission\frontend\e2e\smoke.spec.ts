﻿import { expect, test } from "@playwright/test";

test("login page renders", async ({ page }) => {
  await page.goto("/login");
  await expect(page.getByRole("heading", { name: "Login" })).toBeVisible();
});

test("login then jobs list visible", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Email").fill("admin@local.test");
  await page.getByLabel("Password").fill("Admin123!");
  await page.getByRole("button", { name: "Login" }).click();

  await expect(page).toHaveURL(/\/jobs/);
  await expect(page.getByRole("heading", { name: "Jobs" })).toBeVisible();
});

test("open job detail from jobs page", async ({ page }) => {
  await page.goto("/login");
  await page.getByLabel("Email").fill("admin@local.test");
  await page.getByLabel("Password").fill("Admin123!");
  await page.getByRole("button", { name: "Login" }).click();

  const firstView = page.getByRole("link", { name: "View" }).first();
  if (await firstView.isVisible()) {
    await firstView.click();
    await expect(page.getByRole("heading", { name: /Job Detail|.+/ })).toBeVisible();
  }
});
