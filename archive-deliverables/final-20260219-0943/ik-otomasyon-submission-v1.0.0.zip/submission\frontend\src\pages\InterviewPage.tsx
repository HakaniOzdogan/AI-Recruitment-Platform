﻿import { AxiosError } from "axios";
import { FormEvent, useEffect, useMemo, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import {
  getInterview,
  getInterviewAiDebug,
  getInterviewMessages,
  InterviewAiState,
  InterviewMessage,
  InterviewSession,
  postInterviewMessage,
  setInterviewMode
} from "../api/endpoints/interviews";
import { HumanOverridePayload, getScorecard, postHumanOverride, runAutoScore, ScorecardResponse } from "../api/endpoints/scoring";
import { ChatBubble } from "../components/ChatBubble";
import { Collapsible } from "../components/Collapsible";
import { JsonErrorBox } from "../components/JsonErrorBox";
import { LoadingSpinner } from "../components/LoadingSpinner";
import { ModeToggle } from "../components/ModeToggle";
import { PanelCard } from "../components/PanelCard";
import { ScorePill } from "../components/ScorePill";
import { buildCandidateUrl } from "../routes/nav";
import { pushToast } from "../store/uiFeedback";

type Mode = "OFF" | "ASSIST" | "ADAPTIVE";
type CriterionKey = HumanOverridePayload["criterionKey"];

type InterviewState = {
  loading: boolean;
  error: unknown;
  data: InterviewSession | null;
};

type DebugState = {
  loading: boolean;
  error: unknown;
  data: InterviewAiState | null;
  unavailable: boolean;
};

type ModeState = {
  switching: boolean;
};

const criterionKeys: CriterionKey[] = ["technical", "problem_solving", "communication", "culture_fit", "domain_knowledge"];

function parseDebugJson(value?: string | null): unknown {
  if (!value) {
    return null;
  }

  try {
    return JSON.parse(value);
  } catch {
    return value;
  }
}

function getErrorMessage(error: unknown, fallback: string): string {
  if (error instanceof AxiosError) {
    return (error.response?.data as { message?: string } | undefined)?.message ?? fallback;
  }

  if (error instanceof Error) {
    return error.message;
  }

  return fallback;
}

function toScorePillValue(score: number | null): number {
  if (score === null || Number.isNaN(score)) {
    return 0;
  }

  return Math.round((score / 5) * 100);
}

function extractPlanQuestions(debug: InterviewAiState | null): Array<{ text: string; category?: string; topic?: string }> {
  const parsed = parseDebugJson(debug?.latestPlanJson) as Record<string, unknown> | null;
  if (!parsed || typeof parsed !== "object") {
    return [];
  }

  const plan = parsed.planned_questions;
  if (!Array.isArray(plan)) {
    return [];
  }

  return plan
    .map((item) => {
      if (!item || typeof item !== "object") {
        return null;
      }
      const row = item as Record<string, unknown>;
      const text = typeof row.question_text === "string" ? row.question_text : "";
      if (!text) {
        return null;
      }

      return {
        text,
        category: typeof row.category === "string" ? row.category : undefined,
        topic: typeof row.topic_key === "string" ? row.topic_key : undefined
      };
    })
    .filter((x): x is { text: string; category?: string; topic?: string } => x !== null);
}

function extractInsightSignals(debug: InterviewAiState | null): string[] {
  const parsed = parseDebugJson(debug?.latestInsightJson) as Record<string, unknown> | null;
  if (!parsed || typeof parsed !== "object") {
    return [];
  }

  const signals = parsed.signals;
  if (!Array.isArray(signals)) {
    return [];
  }

  return signals
    .map((item) => {
      if (!item || typeof item !== "object") {
        return null;
      }

      const row = item as Record<string, unknown>;
      const term = typeof row.term === "string" ? row.term : null;
      const topic = typeof row.topic_key === "string" ? row.topic_key : null;
      if (!term && !topic) {
        return null;
      }

      return term && topic ? `${term} (${topic})` : (term ?? topic ?? null);
    })
    .filter((x): x is string => !!x);
}

export function InterviewPage(): JSX.Element {
  const { sessionId } = useParams();
  const [searchParams] = useSearchParams();
  const id = sessionId ?? "";
  const queryJobId = searchParams.get("jobId");
  const queryCandidateId = searchParams.get("candidateId");
  const queryAppId = searchParams.get("appId");

  const [mode, setMode] = useState<Mode>("OFF");
  const [interviewState, setInterviewState] = useState<InterviewState>({ loading: false, error: null, data: null });
  const [debugState, setDebugState] = useState<DebugState>({ loading: false, error: null, data: null, unavailable: false });
  const [modeState, setModeState] = useState<ModeState>({ switching: false });

  const [messages, setMessages] = useState<InterviewMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [messagesError, setMessagesError] = useState<unknown>(null);
  const [messageInput, setMessageInput] = useState("");
  const [sending, setSending] = useState(false);
  const [messagesEndpointAvailable, setMessagesEndpointAvailable] = useState(true);
  const [messagesForbidden, setMessagesForbidden] = useState(false);

  const [scorecard, setScorecard] = useState<ScorecardResponse | null>(null);
  const [scoreLoading, setScoreLoading] = useState(false);
  const [scoreError, setScoreError] = useState<unknown>(null);
  const [scoreNotice, setScoreNotice] = useState<string | null>(null);
  const [forceAuto, setForceAuto] = useState(true);
  const [autoScoring, setAutoScoring] = useState(false);
  const [scoreForbidden, setScoreForbidden] = useState(false);

  const [overrideOpen, setOverrideOpen] = useState(false);
  const [overrideCriterion, setOverrideCriterion] = useState<CriterionKey>("technical");
  const [overrideScore, setOverrideScore] = useState("3");
  const [overrideRationale, setOverrideRationale] = useState("");
  const [overrideEvidence, setOverrideEvidence] = useState("");
  const [overrideRelatedTo, setOverrideRelatedTo] = useState("");
  const [overrideSubmitting, setOverrideSubmitting] = useState(false);
  const [overrideClientError, setOverrideClientError] = useState<string | null>(null);
  const [overrideServerError, setOverrideServerError] = useState<unknown>(null);

  async function loadInterview() {
    if (!id) {
      return;
    }

    setInterviewState((state) => ({ ...state, loading: true, error: null }));
    try {
      const session = await getInterview(id);
      setInterviewState({ loading: false, error: null, data: session });
      const modeValue = (session as InterviewSession & { aiMode?: string }).aiMode;
      if (modeValue === "OFF" || modeValue === "ASSIST" || modeValue === "ADAPTIVE") {
        setMode(modeValue);
      }
    } catch (err) {
      setInterviewState({ loading: false, error: err, data: null });
    }
  }

  async function loadMessages() {
    if (!id || !messagesEndpointAvailable) {
      return;
    }

    setMessagesLoading(true);
    setMessagesError(null);
    try {
      const data = await getInterviewMessages(id);
      setMessages(data);
      setMessagesForbidden(false);
    } catch (err) {
      if (err instanceof AxiosError && err.response?.status === 404) {
        setMessagesEndpointAvailable(false);
      } else if (err instanceof AxiosError && err.response?.status === 403) {
        setMessagesForbidden(true);
      } else {
        setMessagesError(err);
      }
    } finally {
      setMessagesLoading(false);
    }
  }

  async function loadAiDebug() {
    if (!id) {
      return;
    }

    setDebugState((state) => ({ ...state, loading: true, error: null }));
    try {
      const data = await getInterviewAiDebug(id);
      setDebugState({ loading: false, error: null, data, unavailable: false });
      if (data.aiMode === "OFF" || data.aiMode === "ASSIST" || data.aiMode === "ADAPTIVE") {
        setMode(data.aiMode);
      }
    } catch (err) {
      if (err instanceof AxiosError && (err.response?.status === 403 || err.response?.status === 404)) {
        setDebugState({ loading: false, error: null, data: null, unavailable: true });
        return;
      }

      setDebugState({ loading: false, error: err, data: null, unavailable: false });
    }
  }

  async function loadScorecard() {
    if (!id) {
      return;
    }

    setScoreLoading(true);
    setScoreError(null);
    setScoreNotice(null);
    try {
      const data = await getScorecard(id);
      setScorecard(data);
      setScoreForbidden(false);
    } catch (err) {
      if (err instanceof AxiosError && err.response?.status === 404) {
        setScorecard(null);
      } else if (err instanceof AxiosError && err.response?.status === 403) {
        setScoreForbidden(true);
      } else {
        setScoreError(err);
      }
    } finally {
      setScoreLoading(false);
    }
  }

  useEffect(() => {
    void loadInterview();
    void loadMessages();
    void loadAiDebug();
    void loadScorecard();
  }, [id]);

  async function onModeChange(next: Mode) {
    if (!id) {
      return;
    }

    setModeState({ switching: true });
    try {
      await setInterviewMode(id, { aiMode: next });
      await loadInterview();
      await loadAiDebug();
      setMode(next);
      pushToast("info", `Mode güncellendi: ${next}`);
    } catch (err) {
      if (err instanceof AxiosError && err.response?.status === 409) {
        pushToast("error", "Adaptive devre dışı / LLM kapalı");
      } else if (err instanceof AxiosError && err.response?.status === 403) {
        pushToast("error", "Mode değiştirme için yetkin yok");
      } else {
        pushToast("error", getErrorMessage(err, "Mode güncellenemedi"));
      }
    } finally {
      setModeState({ switching: false });
    }
  }

  async function onSend(event: FormEvent) {
    event.preventDefault();
    if (!id || !messageInput.trim()) {
      return;
    }

    const text = messageInput.trim();
    setSending(true);

    try {
      const turn = await postInterviewMessage(id, { text });
      setMessages((state) => [
        ...state,
        { role: "candidate", content: text },
        ...(turn.systemQuestion ? [{ role: "system", content: turn.systemQuestion }] : [])
      ]);
      setMessageInput("");
      await loadAiDebug();
      if (messagesEndpointAvailable) {
        await loadMessages();
      }
    } catch (err) {
      setMessagesError(err);
    } finally {
      setSending(false);
    }
  }

  async function onRunAutoScore() {
    if (!id) {
      return;
    }

    setAutoScoring(true);
    setScoreError(null);
    setScoreNotice(null);
    try {
      const data = await runAutoScore(id, forceAuto);
      setScorecard(data);
      setScoreForbidden(false);
      setScoreNotice("Auto score tamamlandı.");
      await loadScorecard();
    } catch (err) {
      if (err instanceof AxiosError && err.response?.status === 403) {
        setScoreForbidden(true);
        setScoreNotice("Scorecard için yetkin yok.");
        return;
      }
      if (err instanceof AxiosError && err.response?.status === 409) {
        setScoreNotice(getErrorMessage(err, "Session henüz scoring için uygun değil"));
      } else {
        setScoreError(err);
      }
    } finally {
      setAutoScoring(false);
    }
  }

  function openOverrideModal(key: string) {
    const normalized = criterionKeys.includes(key as CriterionKey) ? (key as CriterionKey) : "technical";
    setOverrideCriterion(normalized);
    setOverrideScore("3");
    setOverrideRationale("");
    setOverrideEvidence("");
    setOverrideRelatedTo(normalized);
    setOverrideClientError(null);
    setOverrideServerError(null);
    setOverrideOpen(true);
  }

  async function onSubmitOverride(event: FormEvent) {
    event.preventDefault();
    if (!id) {
      return;
    }

    const evidence = overrideEvidence.trim();
    const rationale = overrideRationale.trim();
    const numericScore = Number(overrideScore);

    if (!rationale) {
      setOverrideClientError("Rationale zorunlu");
      return;
    }

    if (!evidence) {
      setOverrideClientError("En az 1 non-empty evidence quote gerekli");
      return;
    }

    if (evidence.length > 200) {
      setOverrideClientError("Evidence quote 200 karakterden uzun olamaz");
      return;
    }

    if (Number.isNaN(numericScore) || numericScore < 0 || numericScore > 5) {
      setOverrideClientError("Score 0 ile 5 arasında olmalı");
      return;
    }

    setOverrideSubmitting(true);
    setOverrideClientError(null);
    setOverrideServerError(null);
    setScoreError(null);
    setScoreNotice(null);

    try {
      const payload: HumanOverridePayload = {
        criterionKey: overrideCriterion,
        score: numericScore,
        rationale,
        evidenceQuotes: [
          {
            quote: evidence,
            relatedTo: (overrideRelatedTo || overrideCriterion).trim()
          }
        ]
      };

      const data = await postHumanOverride(id, payload);
      setScorecard(data);
      setScoreForbidden(false);
      setScoreNotice("Override kaydedildi.");
      setOverrideOpen(false);
      await loadScorecard();
    } catch (err) {
      if (err instanceof AxiosError && err.response?.status === 403) {
        setScoreForbidden(true);
        setScoreNotice("Override için yetkin yok.");
        return;
      }
      if (err instanceof AxiosError && err.response?.status === 409) {
        setOverrideClientError(getErrorMessage(err, "Çakışma: override kaydedilemedi"));
        return;
      }
      if (err instanceof AxiosError && err.response?.status === 400) {
        setOverrideServerError(err);
        return;
      }
      setScoreError(err);
    } finally {
      setOverrideSubmitting(false);
    }
  }

  const scoreInlineError =
    scoreError instanceof Error && !(scoreError instanceof AxiosError)
      ? scoreError.message
      : scoreError instanceof AxiosError
        ? ((scoreError.response?.data as { message?: string } | undefined)?.message ?? "Scorecard işlemi başarısız")
        : null;

  const interviewInlineError = interviewState.error ? getErrorMessage(interviewState.error, "Interview yüklenemedi") : null;
  const latestSorted = useMemo(
    () => (scorecard?.latest ? [...scorecard.latest].sort((a, b) => a.criterionKey.localeCompare(b.criterionKey)) : []),
    [scorecard]
  );
  const plannedQuestions = useMemo(() => extractPlanQuestions(debugState.data), [debugState.data]);
  const insightSignals = useMemo(() => extractInsightSignals(debugState.data), [debugState.data]);

  return (
    <section className="card">
      <div className="row-actions">
        <div>
          <h1>Interview Session</h1>
          <p>Session: {id}</p>
          {interviewState.data?.status ? <p>Status: {interviewState.data.status}</p> : null}
        </div>
        <div className="row-actions">
          {queryJobId ? <Link to={`/jobs/${queryJobId}`}>← Back Job</Link> : null}
          {queryCandidateId ? <Link to={buildCandidateUrl(queryCandidateId, queryJobId)}>Back Candidate</Link> : null}
          {queryJobId && queryAppId ? <Link to={`/jobs/${queryJobId}#applications`}>Back Application</Link> : null}
          {!queryJobId && !queryCandidateId && !queryAppId ? (
            <button type="button" onClick={() => window.history.back()}>
              ← Back
            </button>
          ) : null}
        </div>
      </div>

      {interviewState.loading ? <LoadingSpinner label="Interview yükleniyor..." /> : null}
      {interviewInlineError ? <p className="inline-error">{interviewInlineError}</p> : null}
      <JsonErrorBox error={interviewState.error} />

      <PanelCard title="Mode">
        <ModeToggle value={mode} onChange={(next) => void onModeChange(next)} disabled={modeState.switching} />
        {modeState.switching ? <p className="muted">Mode güncelleniyor...</p> : null}
        <div className="row-actions">
          <button type="button" onClick={() => void loadInterview()} disabled={interviewState.loading || modeState.switching}>
            Refresh Session
          </button>
          <button type="button" onClick={() => void loadAiDebug()} disabled={debugState.loading || modeState.switching}>
            Refresh AI
          </button>
        </div>
      </PanelCard>

      <PanelCard
        title="Messages"
        actions={
          <button type="button" onClick={() => void loadMessages()} disabled={!messagesEndpointAvailable}>
            Refresh
          </button>
        }
      >
        {!messagesEndpointAvailable ? <p className="muted">Messages endpoint mevcut değil; gönderilen mesajlar local gösteriliyor.</p> : null}
        {messagesForbidden ? <p className="inline-error">Messages paneli için yetkin yok.</p> : null}
        {messagesLoading ? <LoadingSpinner label="Mesajlar yükleniyor..." /> : null}
        {messagesError ? <p className="inline-error">{getErrorMessage(messagesError, "Mesajlar yüklenemedi")}</p> : null}
        <JsonErrorBox error={messagesError} />

        <div className="chat-list">
          {messages.map((item, index) => (
            <ChatBubble key={`${item.role}-${index}`} role={item.role}>
              {item.content}
            </ChatBubble>
          ))}
        </div>
        {!messagesLoading && !messagesError && !messagesForbidden && messages.length === 0 ? (
          <p className="muted">Henüz mesaj yok, ilk soruyu gönder.</p>
        ) : null}

        <form onSubmit={onSend} className="row-actions">
          <input
            placeholder="Mesaj yaz"
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            disabled={sending || messagesForbidden}
            autoFocus
          />
          <button type="submit" disabled={sending || !messageInput.trim() || messagesForbidden}>
            {sending ? "Gönderiliyor..." : "Send"}
          </button>
        </form>
      </PanelCard>

      <PanelCard
        title="AI Debug"
        actions={
          <button type="button" onClick={() => void loadAiDebug()} disabled={debugState.loading}>
            Refresh AI
          </button>
        }
      >
        {debugState.loading ? <LoadingSpinner label="AI debug yükleniyor..." /> : null}

        {debugState.unavailable ? <p className="muted">Debug info unavailable.</p> : null}
        {!debugState.unavailable && debugState.error ? <p className="inline-error">Debug yüklenemedi.</p> : null}
        {!debugState.unavailable ? <JsonErrorBox error={debugState.error} /> : null}

        {debugState.data ? (
          <>
            <div className="row-actions">
              <span>Guardrail: {debugState.data.guardrailBlocked ? "ON" : "OFF"}</span>
              <span>Fallback: {debugState.data.fallbackUsed ? "USED" : "NO"}</span>
              <span>Mode: {debugState.data.aiMode}</span>
            </div>

            <Collapsible title="Insight Signals">
              {insightSignals.length === 0 ? (
                <p className="muted">Signal yok.</p>
              ) : (
                <ul>
                  {insightSignals.map((signal, idx) => (
                    <li key={`signal-${idx}`}>{signal}</li>
                  ))}
                </ul>
              )}
              <pre>{JSON.stringify(parseDebugJson(debugState.data.latestInsightJson), null, 2)}</pre>
            </Collapsible>

            <Collapsible title="Planned Questions">
              {plannedQuestions.length === 0 ? (
                <p className="muted">Plan sorusu yok.</p>
              ) : (
                <ul>
                  {plannedQuestions.map((q, idx) => (
                    <li key={`plan-${idx}`}>
                      {q.text}
                      {q.category ? ` [${q.category}]` : ""}
                      {q.topic ? ` (${q.topic})` : ""}
                    </li>
                  ))}
                </ul>
              )}
              <pre>{JSON.stringify(parseDebugJson(debugState.data.latestPlanJson), null, 2)}</pre>
            </Collapsible>
          </>
        ) : null}
      </PanelCard>

      <PanelCard
        title="Scorecard"
        actions={
          <div className="row-actions">
            <label className="row-actions">
              <input type="checkbox" checked={forceAuto} onChange={(e) => setForceAuto(e.target.checked)} />
              force
            </label>
            <button type="button" onClick={() => void onRunAutoScore()} disabled={autoScoring || scoreForbidden}>
              {autoScoring ? "Çalışıyor..." : "Run Auto Score"}
            </button>
            <button type="button" onClick={() => void loadScorecard()} disabled={scoreLoading || scoreForbidden}>
              Refresh Scorecard
            </button>
          </div>
        }
      >
        {scoreLoading ? <LoadingSpinner label="Scorecard yükleniyor..." /> : null}
        {scoreForbidden ? <p className="inline-error">Scorecard paneli için yetkin yok.</p> : null}
        {scoreNotice ? <p className="muted">{scoreNotice}</p> : null}
        {scoreInlineError ? <p className="inline-error">{scoreInlineError}</p> : null}
        <JsonErrorBox error={scoreError} />
        {!scoreForbidden && scoreError ? (
          <button type="button" onClick={() => void loadScorecard()} disabled={scoreLoading}>
            Retry Scorecard
          </button>
        ) : null}

        {!scorecard ? (
          <p className="muted">Henüz skor yok. Run Auto Score ile başlat.</p>
        ) : (
          <>
            <div className="row-actions">
              <strong>Overall:</strong>
              {scorecard.overallScore === null ? <span className="muted">null</span> : <ScorePill score={toScorePillValue(scorecard.overallScore)} />}
              <span className="muted">Created: {new Date(scorecard.createdAt).toLocaleString()}</span>
              {scorecard.insufficientAll ? <span className="inline-error">Tüm kriterler: Kanıt yok</span> : null}
            </div>
            <p className="muted">LLM enrichment: {scorecard.llmEnrichment}</p>

            <div className="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Criterion</th>
                    <th>Status</th>
                    <th>Score</th>
                    <th>Evaluator</th>
                    <th>Created</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {latestSorted.map((criterion) => (
                    <tr key={criterion.criterionKey}>
                      <td>{criterion.criterionKey}</td>
                      <td>{criterion.status === "INSUFFICIENT_EVIDENCE" ? "Kanıt yok" : criterion.status}</td>
                      <td>{criterion.score === null ? "-" : criterion.score}</td>
                      <td>{criterion.evaluatorType}</td>
                      <td>{new Date(criterion.createdAt).toLocaleString()}</td>
                      <td>
                        <button type="button" onClick={() => openOverrideModal(criterion.criterionKey)} disabled={scoreForbidden}>
                          Override
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {latestSorted.map((criterion) => (
              <Collapsible key={`${criterion.criterionKey}-details`} title={`${criterion.criterionKey} details`}>
                <p>
                  <strong>Rationale:</strong> {criterion.rationale ?? "-"}
                </p>
                <strong>Evidence</strong>
                <ul>
                  {criterion.evidenceQuotes.map((quote, index) => (
                    <li key={`${criterion.criterionKey}-q-${index}`}>
                      "{quote.quote}" ({quote.relatedTo})
                    </li>
                  ))}
                </ul>
              </Collapsible>
            ))}
          </>
        )}
      </PanelCard>

      <Collapsible title="Open Human Override Form">
        <button type="button" onClick={() => openOverrideModal("technical")}>Yeni Override</button>
      </Collapsible>

      <div className="modal-overlay" style={{ display: overrideOpen ? "flex" : "none" }}>
        <div className="modal-card">
          <h3>Human Override</h3>
          <form onSubmit={onSubmitOverride} className="form-grid">
            <label>
              Criterion
              <select value={overrideCriterion} onChange={(e) => setOverrideCriterion(e.target.value as CriterionKey)}>
                {criterionKeys.map((key) => (
                  <option key={key} value={key}>
                    {key}
                  </option>
                ))}
              </select>
            </label>

            <label>
              Score (0..5)
              <input type="number" min={0} max={5} step={1} value={overrideScore} onChange={(e) => setOverrideScore(e.target.value)} required />
            </label>

            <label>
              Rationale
              <textarea rows={3} value={overrideRationale} onChange={(e) => setOverrideRationale(e.target.value)} required />
            </label>

            <label>
              Evidence Quote (max 200)
              <textarea rows={2} value={overrideEvidence} onChange={(e) => setOverrideEvidence(e.target.value)} required maxLength={200} />
            </label>

            <label>
              Related To
              <input value={overrideRelatedTo} onChange={(e) => setOverrideRelatedTo(e.target.value)} placeholder={overrideCriterion} />
            </label>

            {overrideClientError ? <p className="inline-error">{overrideClientError}</p> : null}

            <div className="row-actions">
              <button type="button" onClick={() => setOverrideOpen(false)} disabled={overrideSubmitting}>
                Cancel
              </button>
              <button type="submit" disabled={overrideSubmitting || scoreForbidden}>
                {overrideSubmitting ? "Kaydediliyor..." : "Submit Override"}
              </button>
            </div>
            <JsonErrorBox error={overrideServerError} />
          </form>
        </div>
      </div>
    </section>
  );
}
