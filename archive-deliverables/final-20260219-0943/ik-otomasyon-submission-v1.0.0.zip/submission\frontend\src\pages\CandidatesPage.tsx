﻿import { AxiosError } from "axios";
import { FormEvent, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Candidate, CandidateCreatePayload, createCandidate, getCandidates } from "../api/endpoints/candidates";
import { ConfirmDialog } from "../components/ConfirmDialog";
import { EmptyState } from "../components/EmptyState";
import { JsonErrorBox } from "../components/JsonErrorBox";
import { LoadingSpinner } from "../components/LoadingSpinner";

const initialForm: CandidateCreatePayload = {
  fullName: "",
  email: null,
  phone: null,
  source: null
};

export function CandidatesPage(): JSX.Element {
  const [items, setItems] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<CandidateCreatePayload>(initialForm);
  const [lastError, setLastError] = useState<unknown>(null);

  async function loadCandidates() {
    setLoading(true);
    setLastError(null);
    try {
      const data = await getCandidates();
      setItems(data);
    } catch (error) {
      setLastError(error);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadCandidates();
  }, []);

  async function handleCreate(event: FormEvent) {
    event.preventDefault();
    setSaving(true);
    setLastError(null);

    try {
      await createCandidate({
        fullName: form.fullName.trim(),
        email: form.email?.trim() || null,
        phone: form.phone?.trim() || null,
        source: form.source?.trim() || null
      });

      setForm(initialForm);
      setShowCreate(false);
      await loadCandidates();
    } catch (error) {
      setLastError(error);
    } finally {
      setSaving(false);
    }
  }

  const plainError =
    lastError instanceof AxiosError && lastError.response?.status !== 400
      ? (lastError.response?.data as { message?: string } | undefined)?.message ?? "İşlem başarısız"
      : null;

  return (
    <section className="card">
      <div className="row-actions">
        <h1>Candidates</h1>
        <div className="row-actions">
          <button type="button" onClick={() => void loadCandidates()} disabled={loading}>
            Yenile
          </button>
          <button type="button" onClick={() => setShowCreate(true)}>
            Create Candidate
          </button>
        </div>
      </div>

      {loading ? <LoadingSpinner /> : null}
      {plainError ? <p className="inline-error">{plainError}</p> : null}
      <JsonErrorBox error={lastError} />

      {items.length === 0 && !loading ? (
        <>
          <EmptyState title="Henüz aday yok" message="Demo için ilk adayı şimdi oluştur." />
          <button type="button" onClick={() => setShowCreate(true)}>
            Create Candidate
          </button>
        </>
      ) : null}

      {items.length > 0 ? (
        <div className="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Created At</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item.id}>
                  <td>{item.fullName}</td>
                  <td>{item.email ?? "-"}</td>
                  <td>{new Date(item.createdAt).toLocaleString()}</td>
                  <td>
                    <Link to={`/candidates/${item.id}`}>View</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : null}

      <ConfirmDialog
        open={showCreate}
        title="Create Candidate"
        showActions={false}
        onCancel={() => {
          setShowCreate(false);
          setForm(initialForm);
        }}
        onConfirm={() => {}}
      >
        <form onSubmit={handleCreate} className="form-grid">
          <label>
            Full Name
            <input value={form.fullName} onChange={(e) => setForm((s) => ({ ...s, fullName: e.target.value }))} required />
          </label>
          <label>
            Email
            <input value={form.email ?? ""} onChange={(e) => setForm((s) => ({ ...s, email: e.target.value }))} />
          </label>
          <label>
            Phone
            <input value={form.phone ?? ""} onChange={(e) => setForm((s) => ({ ...s, phone: e.target.value }))} />
          </label>
          <div className="row-actions">
            <button type="button" onClick={() => setShowCreate(false)}>
              Cancel
            </button>
            <button type="submit" disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
        </form>
      </ConfirmDialog>
    </section>
  );
}
