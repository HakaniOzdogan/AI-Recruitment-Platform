#!/usr/bin/env bash
set -uo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
API_BASE_URL="${API_BASE_URL:-http://localhost:8080}"
TIMESTAMP="$(date +%Y%m%d-%H%M)"
OUT_DIR="${ROOT_DIR}/evidence/${TIMESTAMP}"
TEST_OUT_DIR="${OUT_DIR}/tests"
FAILURES=()
STEP_SWAGGER="FAIL"
STEP_TESTS="FAIL"
STEP_MIGRATIONS="FAIL"
STEP_VULN="FAIL"
STEP_CI="FAIL"

mkdir -p "${OUT_DIR}" "${TEST_OUT_DIR}"

echo "[1/6] Swagger export"
if ! curl -fsS "${API_BASE_URL}/swagger/v1/swagger.json" -o "${OUT_DIR}/swagger.json"; then
  echo "WARN: Swagger indirilemedi (${API_BASE_URL}). Devam ediliyor." | tee "${OUT_DIR}/swagger.warn.txt"
  FAILURES+=("swagger")
else
  STEP_SWAGGER="OK"
fi

echo "[2/6] Test reports"
if command -v dotnet >/dev/null 2>&1; then
  if ! dotnet test -c Release --no-build --logger "trx;LogFileName=unit-integration.trx" --results-directory "${TEST_OUT_DIR}"; then
    FAILURES+=("tests")
  else
    STEP_TESTS="OK"
  fi
else
  echo "dotnet bulunamadi, test raporu alinmadi" > "${TEST_OUT_DIR}/warning.txt"
  FAILURES+=("tests")
fi

echo "[3/6] Migrations list"
if command -v dotnet >/dev/null 2>&1; then
  if ! (cd "${ROOT_DIR}" && dotnet tool restore >/dev/null 2>&1; cd "${ROOT_DIR}/backend" && dotnet dotnet-ef migrations list) > "${OUT_DIR}/migrations.txt" 2>&1; then
    FAILURES+=("migrations")
  else
    STEP_MIGRATIONS="OK"
  fi
else
  echo "dotnet bulunamadi" > "${OUT_DIR}/migrations.txt"
  FAILURES+=("migrations")
fi

echo "[4/6] Vulnerability scan"
if command -v dotnet >/dev/null 2>&1; then
  if ! (cd "${ROOT_DIR}/backend" && dotnet list package --vulnerable --include-transitive) > "${OUT_DIR}/vuln.txt" 2>&1; then
    FAILURES+=("vuln-scan")
  else
    STEP_VULN="OK"
  fi
else
  echo "dotnet bulunamadi" > "${OUT_DIR}/vuln.txt"
  FAILURES+=("vuln-scan")
fi

echo "[5/6] CI summary"
if [[ -f "${ROOT_DIR}/.github/workflows/ci.yml" ]]; then
  {
    echo "CI workflow file: .github/workflows/ci.yml"
    echo "Expected jobs: build_test, migrations_drift, security_vuln, frontend build"
    echo "Run URL template: <repo>/actions/workflows/ci.yml"
  } > "${OUT_DIR}/ci-summary.txt"
  STEP_CI="OK"
else
  echo "ci.yml bulunamadi" > "${OUT_DIR}/ci-summary.txt"
fi

echo "[6/6] Index"
cat > "${OUT_DIR}/README.txt" <<EOF
Evidence bundle generated at: ${TIMESTAMP}
API base: ${API_BASE_URL}
Files:
- swagger.json
- migrations.txt
- vuln.txt
- ci-summary.txt
- tests/*.trx
EOF

if [[ ${#FAILURES[@]} -gt 0 ]]; then
  printf "%s\n" "Failures: ${FAILURES[*]}" > "${OUT_DIR}/summary.txt"
  echo "Completed with warnings. See ${OUT_DIR}/summary.txt"
else
  echo "All steps succeeded." > "${OUT_DIR}/summary.txt"
fi

cat > "${OUT_DIR}/step-status.txt" <<EOF
swagger=${STEP_SWAGGER}
tests=${STEP_TESTS}
migrations=${STEP_MIGRATIONS}
vuln-scan=${STEP_VULN}
ci-summary=${STEP_CI}
EOF

echo "Done: ${OUT_DIR}"
