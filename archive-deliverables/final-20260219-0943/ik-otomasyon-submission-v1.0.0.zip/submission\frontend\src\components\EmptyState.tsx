﻿export function EmptyState({ title, message }: { title: string; message: string }): JSX.Element {
  return (
    <div className="empty-state">
      <strong>{title}</strong>
      <p>{message}</p>
    </div>
  );
}
