# Screenshot Plani

## Isimlendirme Standardi
- `01-jobs.png`
- `02-weights.png`
- `03-matches.png`
- `04-cv-upload.png`
- `05-cv-profile.png`
- `06-ai-eval.png`
- `07-applications.png`
- `08-interview-chat.png`
- `09-ai-debug.png`
- `10-scorecard.png`
- `11-human-override.png`
- `12-403-weights-partial.png`
- `13-insufficient-evidence.png`
- `14-correlation-toast.png`

## Ekran Icerigi
1. Jobs list/create/publish ekrani.
2. Job detail weights (competency toplam 1.0 + skill table).
3. Matching shortlist (reasons/gaps acik).
4. Candidate detail CV upload basarili sonucu.
5. Candidate profile (parse sonrasi).
6. AI evaluation report (overall + strengths/risks).
7. Applications panel (add application + stage).
8. Interview chat ekrani (system + candidate mesajlari).
9. Interview AI debug panel (insight/plan/flags).
10. Scorecard (overall + criterion list).
11. Human override modal ve success sonrasi HUMAN evaluator.
12. 403 weights partial render (sadece weights kilitli, sayfa aktif).
13. `INSUFFICIENT_EVIDENCE` etiketi gorunen scorecard.
14. Hata toastinda `Ref: <correlationId>` gorunumu.

## Toplama Notlari
- Tum screenshotlar ayni demo dataseti ile alinmali.
- Saat damgasi ve surum bilgisi not edilmeli.
- Gerekiyorsa gizli alanlar blurlenmeli (PII).