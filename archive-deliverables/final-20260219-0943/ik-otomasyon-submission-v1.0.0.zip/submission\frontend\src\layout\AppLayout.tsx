﻿import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { logout } from "../auth/auth";

export function AppLayout(): JSX.Element {
  const navigate = useNavigate();

  return (
    <div>
      <header className="top-nav">
        <nav className="top-links">
          <NavLink to="/jobs">Jobs</NavLink>
          <NavLink to="/candidates">Candidates</NavLink>
        </nav>

        <button
          type="button"
          onClick={() => {
            logout();
            navigate("/login", { replace: true });
          }}
        >
          Logout
        </button>
      </header>

      <main className="page-container">
        <Outlet />
      </main>
    </div>
  );
}
