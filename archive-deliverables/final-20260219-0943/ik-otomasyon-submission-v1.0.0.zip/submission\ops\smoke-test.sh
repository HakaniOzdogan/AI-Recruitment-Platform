#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${BASE_URL:-http://localhost:8080}"
EMAIL="${SMOKE_TEST_EMAIL:-}"
PASSWORD="${SMOKE_TEST_PASSWORD:-}"
SMOKE_RUN_MIGRATE="${SMOKE_RUN_MIGRATE:-false}"
SMOKE_MIGRATE_CMD="${SMOKE_MIGRATE_CMD:-docker compose -f docker-compose.prod.yml --env-file .env.prod run --rm migrate}"

if [[ -z "$EMAIL" || -z "$PASSWORD" ]]; then
  echo "SMOKE_TEST_EMAIL ve SMOKE_TEST_PASSWORD ortam degiskenleri zorunlu."
  exit 1
fi

if [[ "${SMOKE_RUN_MIGRATE}" == "true" ]]; then
  echo "[0/4] Migration job kontrolu..."
  eval "${SMOKE_MIGRATE_CMD}"
fi

echo "[1/4] Swagger kontrolu..."
SWAGGER_STATUS="$(curl -s -o /dev/null -w "%{http_code}" "${BASE_URL}/swagger")"
if [[ "$SWAGGER_STATUS" != "200" ]]; then
  echo "Swagger kontrolu basarisiz. status=${SWAGGER_STATUS}"
  exit 1
fi

echo "[2/4] Health kontrolu..."
HEALTH_STATUS="$(curl -s -o /dev/null -w "%{http_code}" "${BASE_URL}/health")"
if [[ "$HEALTH_STATUS" != "200" ]]; then
  echo "Health kontrolu basarisiz. status=${HEALTH_STATUS}"
  exit 1
fi

echo "[3/4] Auth login kontrolu..."
LOGIN_RESPONSE="$(curl -sS -X POST "${BASE_URL}/auth/login" \
  -H "Content-Type: application/json" \
  -d "{\"email\":\"${EMAIL}\",\"password\":\"${PASSWORD}\"}")"

TOKEN="$(printf '%s' "${LOGIN_RESPONSE}" | sed -n 's/.*"accessToken":"\([^"]*\)".*/\1/p')"
if [[ -z "$TOKEN" ]]; then
  echo "Login basarisiz. accessToken alinamadi."
  echo "Response: ${LOGIN_RESPONSE}"
  exit 1
fi

echo "[4/4] Jobs endpoint kontrolu..."
JOBS_STATUS="$(curl -s -o /dev/null -w "%{http_code}" "${BASE_URL}/jobs" \
  -H "Authorization: Bearer ${TOKEN}")"
if [[ "$JOBS_STATUS" != "200" ]]; then
  echo "Jobs kontrolu basarisiz. status=${JOBS_STATUS}"
  exit 1
fi

echo "Smoke test basarili."
