﻿Evidence bundle generated at: 20260219-1047
API base: http://localhost:8080
Files:
- swagger.json
- migrations.txt
- vuln.txt
- ci-summary.txt
- tests/*.trx
